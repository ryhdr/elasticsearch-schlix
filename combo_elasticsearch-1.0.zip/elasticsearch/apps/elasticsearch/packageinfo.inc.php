<?php

$name = 'Elastic Search';
$type = 'app';
$guid = 'b36e0311-2910-32b4-a557-4107681ab3c2';
$version = '1.0';
$license = 'MIT';
$description = 'An alternative site search function for SCHLIX CMS using Elasticsearch. Combo extension consisting of App and Block.';
$author = 'Roy H';
$url = 'https://github.com/ryhdr/elasticsearch-schlix';
$email = 'ryhdr@maysora.com';
$copyright = 'Copyright &copy;2020 Roy H';