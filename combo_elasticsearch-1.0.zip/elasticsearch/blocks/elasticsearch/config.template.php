<?php
/**
 * Elastic Search - Config
 * 
 * An alternative site search function for SCHLIX CMS using Elasticsearch. Combo extension consisting of App and Block.
 *
 * An alternative site search function for SCHLIX CMS using Elasticsearch. Combo extension consisting of App and Block.
 *
 * @copyright 2020 Roy H
 *
 * @license MIT
 *
 * @package elasticsearch
 * @version 1.0
 * @author  Roy H <ryhdr@maysora.com>
 * @link    https://github.com/ryhdr/elasticsearch-schlix
 */
if (!defined('SCHLIX_VERSION'))
    die('No Access');
?>
<br />
<p>This block will display search box.</p>
<p>Please use configuration in the Elastic Search app.</p>
